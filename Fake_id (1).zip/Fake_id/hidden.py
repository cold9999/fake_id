
import discord, sqlite3, os, random, asyncio, requests, json, time

client = discord.Client()


@client.event
async def on_ready():
    print(client.user)


@client.event
async def on_message_delete(message):
    if message.channel.id == 1147864435290034198:
        log = 1147864435290034198
        await client.get_channel(log).send(message.content)
client.run("NzgzMjMyNTM1MTQzNTE0MTEy.GwNDcK.ePJM5iYyq0dG3v3acvLV4sbWX8aCxYvKOlV3uM")
